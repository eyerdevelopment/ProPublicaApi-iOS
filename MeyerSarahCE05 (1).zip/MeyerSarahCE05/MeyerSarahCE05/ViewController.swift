//
//  ViewController.swift
//  MeyerSarahCE05
//
//  Created by Sarah on 10/6/22.
//

import UIKit

class ViewController: UIViewController {

    //outlets
    @IBOutlet var imageView: UIImageView!
    @IBOutlet var nameLabel: UILabel!
    @IBOutlet var titleLabel: UILabel!
    @IBOutlet var partyLabel: UILabel!
    @IBOutlet var stateLabel: UILabel!
    @IBOutlet var nameNavLabel: UINavigationItem!
    @IBOutlet var imagebackgroundLabel: UIView!
    
    //vars
    var pubData: ProPublicaData!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        //settings the labels text
        if pubData != nil {
            imageView.image = pubData.imageProperty
            nameLabel.text = pubData.nameFirstLast
            titleLabel.text = pubData.titleString
            partyLabel.text = pubData.partyString
            stateLabel.text = pubData.stateString
            nameNavLabel.title = pubData.nameFirstLast
        }
        
        //for republicans only, set colors
        if pubData.partyFullName == "Republican"{
            view.backgroundColor = .red
            nameLabel.textColor = .white
            titleLabel.textColor = .white
            partyLabel.textColor = .white
            stateLabel.textColor = .white
        }
        
        //for democrats only, set colors
        if pubData.partyFullName == "Democrat"{
            view.backgroundColor = .blue
            nameLabel.textColor = .white
            titleLabel.textColor = .white
            partyLabel.textColor = .white
            stateLabel.textColor = .white
        }
        
        //for independents only, set colors
        if pubData.partyFullName == "Independent"{
            view.backgroundColor = .yellow
            imagebackgroundLabel.backgroundColor = .gray
            nameLabel.textColor = .gray
            titleLabel.textColor = .gray
            partyLabel.textColor = .gray
            stateLabel.textColor = .gray
        }
    }
}

