//
//  ProPublicaData.swift
//  MeyerSarahCE05
//
//  Created by Sarah on 10/6/22.
//

import Foundation

import UIKit

enum ParsingError: Error {
    case PostParsing
    case Generic
}

class ProPublicaData {
    
    // Stored Properites
    let firstName: String
    let lastName: String
    let title: String
    let party: String
    let state: String
    let id: String
    
    // Computed Properties
    var nameLastFirst: String{ let string = "\(lastName), \(firstName)"; return string }
    var nameFirstLast: String{ let string = "\(firstName) \(lastName)"; return string }
    var partyState: String { let string = "\(party) - \(state)"; return string }
    var titleString: String { let string = "Title: \(title)"; return string }
    var partyString: String { let string = "Party: \(partyFullName)"; return string }
    var stateString: String { let string = "State: \(state)"; return string }
        
    var imageProperty: UIImage {
        var imageFromUrl: UIImage! = nil
        let urlString = "https://theunitedstates.io/images/congress/450x550/\(id).jpg"
        
        if urlString.contains("http"),
           let url = URL(string: urlString),
           var urlComp = URLComponents(url: url, resolvingAgainstBaseURL: false)
        {
            urlComp.scheme = "https"
            
            if let secureURL = urlComp.url {
                do {
                    let imageData = try Data.init(contentsOf: secureURL)
                    imageFromUrl = UIImage(data: imageData)!
                } catch { print(error)}
            }
        }
        return imageFromUrl
        
    }
    
    var partyFullName: String {
            var string = ""
            switch party{
            case "R":
                string = "Republican"
            case "D":
                string = "Democrat"
            case "ID":
                string = "Independent"
            default:
                return ""
            }
            return string
    }
    
    
    //initilizers
    init(firstName: String, lastName: String, title: String, party: String, state: String, id: String) {
        self.firstName = firstName
        self.lastName = lastName
        self.title = title
        self.party = party
        self.state = state
        self.id = id
    }
}
