//
//  TVC_EX.swift
//  MeyerSarahCE05
//
//  Created by Sarah on 10/6/22.
//

import Foundation

extension TableViewController{
    
    //parsing the json and using the API key
    func downloadJSON(atURL urlString: String) {
        let config = URLSessionConfiguration.default
        let session = URLSession(configuration: config)
        if let validURL = URL(string: urlString) {
            var request = URLRequest(url: validURL)
            //taking API key given by propublica website
            request.setValue("gahAYH0R6ckP88gwlNPFWezksW6IIeTLfpOZjhrw", forHTTPHeaderField: "X-API-Key") // propub header key
            request.httpMethod = "GET"
            let task = session.dataTask(with: request, completionHandler: {(opt_data, opt_response, opt_error) in
                
                if opt_error != nil { assertionFailure(); return }
                
                //Check the response, statusCode, and data
                guard let response = opt_response as? HTTPURLResponse,
                      response.statusCode == 200,
                      let data = opt_data
                else { assertionFailure(); return
                }
                
                //parse the data
                do {
                    let json = try JSONSerialization.jsonObject(with: data, options: .mutableContainers) as? [String:Any]
                    guard let jsonObj = json else {print("Parse Failed"); return}
                    if let results = jsonObj["results"] as? [[String: Any]]{
                        for result in results {
                            guard let members = result["members"] as? [[String: Any]]
                            else {continue}
                            for member in members {
                                guard
                                    let firstname = member["first_name"] as? String,
                                    let lastName = member["last_name"] as? String,
                                    let title = member["title"] as? String,
                                    let party = member["party"] as? String,
                                    let state = member["state"] as? String,
                                    let id = member["id"] as? String
                                else { continue }
                                
                                //append the data to the objects
                                self.ProPublicaInfo.append(ProPublicaData(firstName: firstname, lastName: lastName, title: title, party: party, state: state, id: id))
                            }
                        }
                    }
                }
                catch {
                    print(error.localizedDescription)
                    assertionFailure();
                }
                
                //Do UI Stuff
                DispatchQueue.main.async {
                    self.filterPostsByParty()
                    self.tableView.reloadData()
                }
                
            })
            task.resume()
        }
    }
    
    //creating the filtered objects
    func filterPostsByParty() {
        
        //filter by party
        filteredInfo[0] = ProPublicaInfo.filter({ $0.party == "R" })
        filteredInfo[1] = ProPublicaInfo.filter({ $0.party == "D" })
        filteredInfo[2] = ProPublicaInfo.filter({ $0.party == "ID" })
        
    }
    
}
