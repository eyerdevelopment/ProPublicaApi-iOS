//
//  TableViewController.swift
//  MeyerSarahCE05
//
//  Created by Sarah on 10/6/22.
//

import UIKit

class TableViewController: UITableViewController {
    
    var ProPublicaInfo = [ProPublicaData]()
    var filteredInfo = [[ProPublicaData](), [ProPublicaData](), [ProPublicaData]()]
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        downloadJSON(atURL: "https://api.propublica.org/congress/v1/117/house/members.json")
        downloadJSON(atURL: "https://api.propublica.org/congress/v1/117/senate/members.json")
      
    }
    
    //titles for headers in table
    override func tableView(_ tableView: UITableView, titleForHeaderInSection section: Int) -> String? {
        switch section {
        case 0:
            return "Republican"
        case 1:
            return "Democrat"
        case 2:
            return "Independent"
        default:
            return ""
        }
    }
    
    //number of sections in table
    override func numberOfSections(in tableView: UITableView) -> Int {
        return 3
    }
    
    //number of rows of cells in table
    override func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        //return however many filters there are as section number
        return filteredInfo[section].count
    }
    
    //creating the cell with reusable id
    override func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        guard let cell = tableView.dequeueReusableCell(withIdentifier: "cell_ID_1", for: indexPath) as? TableViewCell else {return tableView.dequeueReusableCell(withIdentifier: "cell_ID_1", for: indexPath)}
        
        let currentcell = filteredInfo[indexPath.section][indexPath.row]
        
        cell.nameLabel.text = currentcell.nameLastFirst
        cell.titleLabel.text = currentcell.title
        cell.partyLabel.text = currentcell.partyState

        //color change for republicans
        if currentcell.party == "R"{
            cell.nameLabel.textColor = .white
            cell.titleLabel.textColor = .white
            cell.partyLabel.textColor = .white
            cell.backgroundColor = .red
        }
        
        //color change for democrats
        if currentcell.party == "D"{
            cell.nameLabel.textColor = .white
            cell.titleLabel.textColor = .white
            cell.partyLabel.textColor = .white
            cell.backgroundColor = .blue
        }
        
        //color change for independents
        if currentcell.party == "ID"{
            cell.nameLabel.textColor = .gray
            cell.titleLabel.textColor = .gray
            cell.partyLabel.textColor = .gray
            cell.backgroundColor = .yellow
        }
        
        //return each cell
        return cell
    }
    
    //height for rows
    override func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
         return 70
    }
    
    //height for headers
    override func tableView(_ tableView: UITableView, heightForHeaderInSection section: Int) -> CGFloat {
        return 40
    }

    
    //to send info from one controller to the other
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        
        //for each filter, give the indiviual info to the next view controller
        if let indexPath = tableView.indexPathForSelectedRow {
            let info = filteredInfo[indexPath.section][indexPath.row]
            
            if let destination = segue.destination as? ViewController {
                destination.pubData = info
            }
        }
    }
}
